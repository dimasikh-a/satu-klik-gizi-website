module.exports=[78764,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_home_page_actions_0963r4p.js.map