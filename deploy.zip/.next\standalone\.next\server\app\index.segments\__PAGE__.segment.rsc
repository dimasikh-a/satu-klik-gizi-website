1:"$Sreact.fragment"
3:I[97367,["/_next/static/chunks/0vlcrksse1ta2.js","/_next/static/chunks/0n4z.7yu76je-.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"H49Q-etbOvzLllrJUF_kK"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;./home;307;"}
